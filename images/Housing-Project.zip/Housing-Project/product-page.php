        
    <?php

        include("header.php");

    ?>
    <br/><br/>
    <section class="product-section-first">
    	
    </section>

    <section class="product-section-second mb-4">
    	<div class="container">
    		<div class="product-content">
    			<div class="row">
    				<div class="col-lg-4 images-effect">
    					<a href="#" data-toggle="modal" data-target="#imgModal">
    						<img src="images/sm-img2.jpg" alt="" class="product-img">
    						<div class="overlay-effect">More Images</div>
    					</a>
    				</div>
    				<div class="col-lg-8 mt-2">
    					<div class="d-flex justify-content-between">
    						<p class="px-2 py-1 font12 bg-success text-white">PLATINUM</p>
    						<p class="font14">
    							<span>1 day ago</span>
    							<a href="#"><i class="fas fa-heart ml-2 text-danger"></i></a>
    						</p>
    					</div>
    					<h4>3 bhk 95 Sq. ft Residential Apartments for Rent in munirka,Delhi</h4>
    					<p><a href="#" class="clr">Dwarika</a>, <span>Delhi</span> </p>
    					<p>Apartment in DDA Flats Munirka Property ID: 338763492</p>

    					<div class="row">
    						<div class="col-lg-3 col-md-4">
    							<h2>&#x20B9; 38,000</h2>
    						</div>
    						<div class="col-lg-3 col-md-4 d-flex">
    							<p>share</p>
    							<a href="#">
    							   <i class="fab fa-whatsapp bg-success text-white ml-2 p-1" style="border-radius: 50%;"></i>
    							</a>
    							<a href="#">
    								<i class="fab fa-facebook-f bg-primary text-white ml-2 py-1 px-2" style="border-radius: 50%;">
    									
    								</i>
    							</a>
    							<a href="#">
    								<i class="far fa-envelope bg-danger text-white ml-2 p-1" style="border-radius: 50%;">
    								</i>
    							</a>
    						</div>
    						<div class="col-lg-3 col-md-4">
    							<a href="#">
    								<i class="fas fa-mail-bulk mr-2"></i>
    								<span>Discussion Board</span>
    							</a>
    						</div>

    						<div class="col-lg-3 col-md-4">
    							<a href="#">
    								<i class="fas fa-exclamation-circle mr-2"></i>
    								<span>Report this listing</span>
    							</a>
    						</div>
    					</div>

    					<div class="row">
    						<div class="col-lg-3 col-md-4 col-6 text-center custome-border my-2">
    							<p>Built-Up Area</p>
    							<h5>95 Sq.fit.</h5>
    							<p class="font12">( 8.83 Sq.M )</p>
    						</div>
    						<div class="col-lg-2 col-md-4 col-6 text-center custome-border my-2">
    							<p>Bedroom</p>
    							<h5>3</h5>
    						</div>
    						<div class="col-lg-2 col-md-4 col-6 text-center custome-border my-2">
    							<p>Bathroom</p>
    							<h5>3</h5>
    						</div>
    						<div class="col-lg-3 col-md-6 col-6 text-center custome-border my-2">
    							<p>Available from</p>
    							<h5>2020-06-08</h5>
    						</div>
    						<div class="col-lg-2 col-md-6 col-6 text-center my-2">
    							<p>Security Deposit</p>
    							<h5>&#x20B9; 38,000</h5>
    						</div>
    					</div>

    					<div class="row">
    						<div class="col-lg-6 col-md-6 my-2">
    							<a href="#" class="btn btn-block btn-DDA">DDA Flats Munirka</a>
    						</div>
    						<div class="col-lg-6 col-md-6 my-2">
    							<a href="#" class="btn btn-block btn-contact">Contact Owner</a>
    						</div>
    					</div>

    				</div>
    			</div>
    		</div>
    </section>

    <section class="product-section-third my-4">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-8 my-3">

    				<h3 class="featured">Features</h3>
    				<div class="row mt-3">
    					<div class="col-sm-3 col-6 my-2">
	    					<h6>Balcony</h6>
	    					<p>1</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Floor</h6>
	    					<p>4th</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Carpet Area</h6>
	    					<p>90 Sq.Ft.</p>
	    					<p class="font12">(8.36 Sq.M)</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Property View</h6>
	    					<p>Garden</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>For</h6>
	    					<p>No Preference</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Price Negotiable</h6>
	    					<p>Yes</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Facing Direction</h6>
	    					<p>North East</p>
	    				</div>
	    				<div class="col-sm-3 col-6 my-2">
	    					<h6>Ownership Type</h6>
	    					<p>Freehold</p>
	    				</div>
    				</div>

    				<br/>
    				<h3>Nearby Places and Landmarks</h3>
    				<div class="row NBL mt-5">
    					<div class="col-lg-6" style="border-right: 0.5px solid gray;">
    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span> Kendriya Vidyalaya JNU (Ber Sara...</span>
    							</p>
    							<p>1.1 Km (Approx)</p>
    						</div>

    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span> Delhi Safdarjung Railway Station</span>
    							</p>
    							<p>5.5 Km (Approx)</p>
    						</div>

    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span>Vir Hakikat Rai Bus Terminus</span>
    							</p>
    							<p>14.1 Km (Approx)</p>
    						</div>
    					</div>
    					<div class="col-lg-6">
    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span>Munirka Metro Station</span>
    							</p>
    							<p>0.9 Km (Approx)</p>
    						</div>

    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span>Easyday Supermarket (Munirka)</span>
    							</p>
    							<p>0.6 Km (Approx)</p>
    						</div>

    						<div class="d-flex justify-content-between font14">
    							<p>
    								<i class="far fa-check-square mr-2"></i>
    								<span>Vir Hakikat Rai Bus Terminus</span>
    							</p>
    							<p>14.1 Km (Approx)</p>
    						</div>
    					</div>
    				</div>

					<div class="row mt-5 py-2 bg-light">
						<div class="col-lg-4">
							<h3 class="featured">About Property</h3>
						</div>
						<div class="col-lg-8">
							<p class="font12 mt-2 p-1">
								<i class="far fa-eye mr-1"></i><span>34 People have viewed this property </span> |
								<i class="fas fa-search mr-1"></i><span> 892 Times this property has been searched</span>
							</p>
						</div>
						<p class="border-bottom border-success p-2 font14">
							Located in posh South Delhi, surrounded by greeneries, premier educational institutes and shopping malls; well connected by public transport including metro station in walking distance; the house is quite ventilated with access of sun light; having modular kitchen with chimney; extra water storage tanks; automatic motor con... 
							<a href="#">read more</a>
						</p>
						<p class="px-2">
							<i class="fas fa-american-sign-language-interpreting mr-2 text-danger"></i>
							<strong>Need a home loan</strong>&nbsp;
							<span> to buy your Dream House?</span>
							<a href="#"><strong>Apply Now</strong></a>
						</p>
					</div> 

					<h3 class="featured mt-5">Flat Amenities</h3>
					<div class="row mt-3" style="box-shadow: 0px 2px 4px rgba(0,0,0,0.2);">
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/aircdn.png" alt="" class="Flat-icons" />
							<p>Air Conditioner</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/bed.png" alt="" class="Flat-icons" />
							<p>Bed</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/sofa.png" alt="" class="Flat-icons" />
							<p>Sofa</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/Refrigerator.png" alt="" class="Flat-icons" />
							<p>Refrigerator</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/Wardrobes.png" alt="" class="Flat-icons" />
							<p>Wardrobes</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/dinner.png" alt="" class="Flat-icons" />
							<p>Dining Table</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/digital.png" alt="" class="Flat-icons" />
							<p>TV</p>
						</div>
						<div class="col-lg-3 col-md-3 col-6 my-2 text-center">
							<img src="images/waterfilter.png" alt="" class="Flat-icons" />
							<p>Water Filter</p>
						</div>
					</div> 

					<h3 class="featured mt-5">Society Amenities</h3>
					<div class="row mt-3" style="box-shadow: 0px 2px 4px rgba(0,0,0,0.2);">
						<div class="col-lg-4 p-3">
							<p>
								<i class="far fa-check-circle mr-2"></i>
								<span>Gated Community</span>
							</p>
							<p>
								<i class="fas fa-fan mr-2"></i>
								<span>Landscaped Garden</span>
							</p>
							<p>
								<i class="fas fa-trash-alt mr-2"></i>
								<span>Waste Disposal</span>
							</p>
							<p>
								<i class="far fa-check-circle mr-2"></i>
								<span>Greenery</span>
							</p>
						</div>

						<div class="col-lg-4 p-3">
							<p>
								<i class="fas fa-basketball-ball mr-2"></i>
								<span>Play Area</span>
							</p>
							<p>
								<i class="fas fa-walking mr-2"></i>
								<span>Jogging Track</span>
							</p>
							<p>
								<i class="fas fa-lock mr-2"></i>
								<span>Security Personnel</span>
							</p>
							<p>
								<i class="fas fa-gas-pump mr-2"></i>
								<span>Gas Pipeline</span>
							</p>
						</div>
						<div class="col-lg-4 p-3">
							<p>
								<i class="fas fa-warehouse mr-2"></i>
								<span>Community Hall</span>
							</p>
							<p>
								<i class="fas fa-university mr-2"></i>
								<span>Bank/ATM</span>
							</p>
						</div>
					</div>   				
    			</div>

    			<div class="col-lg-4 my-3">
    				
    				<form>
    					<div class="Interested-Property py-2">
                            <div class="text-center">
                                <h4 class="mt-3">Interested in Property</h4>
                                <p class="font14 mb-5">Fill the form</p>
                            </div>
                            <div class="form-group mt-5">
                                <div class="col-12">
                                    <label class="labels" for="name"><i class="far fa-user mr-2"></i>Name</label>
                                    <input type="text" class="formInput" id="name" name="name" />
                                </div>
                            </div>
                            <div class="form-group my-5">
                                <div class="col-12">
                                    <label class="labels" for="mobile_number"><i class="fas fa-phone mr-2"></i>Mobile Number</label>
                                    <input type="text" class="formInput" id="mobile_number" name="mobile_number"/>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-12">
                                    <label class="labels" for="email"><i class="far fa-envelope-open mr-2"></i>Email</label>
                                    <input type="text" class="formInput" id="password" name="email" />
                                </div>
                            </div>
                            <div class="form-group px-2">
                                <input type="submit" class="modal-frm-btn" value="continue" />
                            </div>
                        </div>
    				</form>

    				<div class="Interested-Property mt-4 p-3 py-4">
    					<div class="d-flex py-2" style="border-bottom: 1px solid #ECF0F1;">
    						<div class="custome-circle mr-3">
    							<i class="far fa-user clr font22"></i>
    						</div>
    						<a href="#">
    							<h5>Sonu Diwakar</h5>
    							<p>Owner</p>
    						</a>
    					</div>
    					<br/>
    					<h4>+91 - 80XXXXXX78</h4>
    					<br/>
    					<a href="#" class="btn btn-block btn-outline-primary">View Number</a>
    				</div>

    			</div>
    		</div>
    	</div>
    </section>


	<div class="container">

	  	<!-- The Modal -->
	  	<div class="modal fade" id="imgModal">
	  		<button type="button" class="close text-right" data-dismiss="modal">&times;</button>
	    	<div class="modal-dialog modal-lg modal-dialog-centered">

	      		<div class="modal-content p-4">
	        		
	        		<div id="MyCarousel" class="carousel slide" data-ride="carousel">
					  
					  <!-- The slideshow -->
					  	<div class="carousel-inner">
						    <div class="carousel-item active">
						      <img src="images/sm-img1.jpg" alt="Los Angeles" width="1100" height="500">
						    </div>
						    <div class="carousel-item">
						      <img src="images/sm-img2.jpg" alt="Chicago" width="1100" height="500">
						    </div>
						    <div class="carousel-item">
						      <img src="images/sm-img3.jpg" alt="New York" width="1100" height="500">
						    </div>
					  	</div>
					  
					  <!-- Left and right controls -->
					  	<a class="carousel-control-prev" href="#MyCarousel" data-slide="prev">
					    	<span class="carousel-control-prev-icon"></span>
					  	</a>
					  	<a class="carousel-control-next" href="#MyCarousel" data-slide="next">
					    	<span class="carousel-control-next-icon"></span>
					  	</a>
					</div>
	        
	      		</div>
	    	</div>
	  	</div>
  
	</div>

   	

    <?php

        include("footer.php");

    ?>