<footer class="footer-area">
			
    <div class="container py-4">
        <div class="row">
            <div class="col-lg-4 my-2">
                <a href="#" class="foot-logo">
                    <img src="images/logo.png" alt="logo">
                </a>
                <p class="footer__desc">
                    Enticing Apartments, a growing name in the industry of selling Hotel Apartments, Villas and Penthouses having immense experience of dealing with all sort of budget and client's requirements.
                </p>
            </div>
            <div class="col-lg-2 col-sm-6 my-3">
                <h4 class="footer__title mt-1 mb-3">Quick Links</h4>
                <ul class="list-items">
                    <li><a href="#" >home</a></li>
                    <li><a href="#" >about us</a></li>
                    <li><a href="#" >contact us</a></li>
                    <li><a href="#" >blog</a></li>
                </ul>
            </div>
            <div class="col-lg-2 col-sm-6 my-3">
                <h4 class="footer__title mt-1 mb-3">Property</h4>
                <ul class="list-items">
                    <li><a href="#" >Hotel Apartment </a></li>
                    <li><a href="#" >Villas</a></li>
                    <li><a href="#" >Penthouse</a></li>
                    <li><a href="#" >View All</a></li>
                </ul>
            </div>
            <div class="col-lg-4 col-sm-12 my-3">
                <h4 class="footer__title mt-1 mb-3">Contact with Us</h4>
                <ul class="info-list contact-links">
                    <li class="clr">
                        <span class="fas fa-home mr-2"></span>LeEnticing Global Tourism LLC<br>
                        Office #10, 23 Floor The Oberoi Center Business Bay Dubai </li>
                    <li class="clr my-2"><span class="fas fa-headphones mr-2"></span><a>+971-45713110</a></li>
                    <li class="clr"><span class="fas fa-envelope-open mr-2"></span><a href="#" class="clr">ops@enticingapartments.com</a></li>
                </ul>
                <ul class="social-profile px-4 mt-2 d-flex justify-content-between">
                    <li class="mr-1 ml-1">
                        <a href="#" target="_blank">
                            <i class="fa fa-facebook"></i>
                        </a>
                    </li>
                    <li class="mr-1 ml-1">
                        <a href="#" target="_blank">
                            <i class="fa fa-twitter"></i>
                        </a>
                    </li>
                    <li class="mr-1 ml-1">
                        <a href="#" target="_blank">
                            <i class="fa fa-linkedin"></i>
                        </a>
                    </li>
                    <li class="mr-1 ml-1">
                        <a href="#" target="_blank">
                            <i class="fa fa-instagram"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>

    <div class="container py-0">
        <hr/>
    </div>

    <div class="container py-4">
        <div class="row">
            <div class="col-lg-6">
                <div class="copy-right text-center">
                    <p class="mt-2">
                        Copyright © 2020 LeEnticing Global Tourism LLC. All rights are reserved.
                    </p>
                </div>
            </div>	
            <div class="col-lg-6">
                <ul class="list-items px-4 d-flex justify-content-between">
                    <li><a href="https://www.enticingapartments.com/terms-and-conditions" >Terms &amp; Conditions</a></li>
                    <li><a href="https://www.enticingapartments.com/privacy-policy" >Privacy Policy</a></li>
                    <li><a href="https://www.enticingapartments.com/contact-us" >Help Center</a></li>
                </ul>
            </div>
        </div>
    </div>
    
</footer>

<div class="mr-auto">
    <a id="back2Top" title="Back to top" href="#"><i class="fas fa-arrow-down"></i></a>
</div>

<!-- The Modal -->
<div class="modal fade" id="myModal">
    <button type="button" class="close mr-2" data-dismiss="modal">&times;</button>
    <div class="modal-dialog modal-lg modal-dialog-centered">
      <div class="modal-content">
        
        <!-- Modal body -->
        <div class="modal-body p-0">
              <div class="row">
                <div class="col-lg-5 p-3 bg-light">
                    <div class="d-flex">
                        <div class="col-4 p-0">
                            <img src="images/location.png" class="modal-png-icon" alt=""/>
                        </div>
                        <div class="col-8 p-3">
                            <h6>Manage your orders</h6>
                            <p>Track your orders, delivery and returns</p>
                        </div>
                    </div>

                    <div class="d-flex">
                        <div class="col-4 p-0">
                            <img src="images/money.png" class="modal-png-icon" alt=""/>
                        </div>
                        <div class="col-8 p-3">
                            <h6>Transact online with buyers and sellers</h6>
                            <p>Check and respond to chats, replies, offers and more</p>
                        </div>
                    </div>

                    <div class="d-flex">
                        <div class="col-4 p-0">
                            <img src="images/seller.png" class="modal-png-icon" alt=""/>
                        </div>
                        <div class="col-8 p-3">
                            <h6>Personalized notifications and alerts</h6>
                            <p>Get matching alerts for the products/services you are looking for</p>
                        </div>
                    </div>
                </div>  

                <div class="clo-lg-7 py-3 px-4">
                    
                    <form class="form" method="post" action="" role="form" name="myForm1" autocomplete="off">
                        
                        <div class="firstTab">
                            <div class="text-center">
                                <h4 class="mt-3">Login/Sign Up On Enticing</h4>
                                <p class="font14 mb-5">Please provide your Mobile Number or Email to Login/Sign Up</p>
                            </div>
                            <div class="form-group">
                                <div class="col-12">
                                    <label class="labels" for="email_number">provide your Mobile Number or Email</label>
                                    <input type="text" onkeypress="myFunction()" class="formInput" id="email_number" name="email_number">
                                    <span class="font12 text-danger" id="demo"></span>
                                </div>
                            </div>
                            <div class="form-group px-2">
                                <input type="button" onclick="return validateForm()" class="modal-frm-btn" value="continue" />
                            </div>

                            <p class="text-center">
                                By submitting in you agree to <span><a href="#">T&C</a></span> and <span><a href="#">Privacy Plicy</a></span>
                            </p>

                            <div class="bg-light d-flex p-3">
                                <img src="images/profit.png" alt="" style="height: 60px;"/>
                                <div class="ml-3">
                                    <h6>Earn Upto <span class="text-success">&#x20B9; 500 QCash</span></h6>
                                    <p>All you need to do is login or sign up!</p>
                                </div>
                            </div>

                            <h5 class="text-center my-3">Log In width</h5>
                            <div class="row">
                                <div class="col-lg-6 col-sm-6 text-center">
                                    <div class="social-btn">
                                        <a href="#" class="d-flex justify-content-center">
                                            <img src="images/facebook.png" alt="" class="social-cons mr-2"/>
                                            <h5>Facebook</h5>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-sm-6 text-center">
                                    <div class="social-btn">
                                        <a href="#" class="d-flex justify-content-center">
                                            <img src="images/google.png" alt="" class="social-cons mr-2"/>
                                            <h5>Google</h5>
                                        </a>
                                    </div>
                                </div>
                            </div>

                        </div>

                        <div class="secondTab" style="display: none;">
                            <i class="fas fa-arrow-left clr back-to-home"></i>
                            <div class="text-center">
                                <h4 class="mt-3">Sign Up On Enticing</h4>
                                <p class="font14 mb-5">Please provide your Mobile Number or Email to Login/Sign Up</p>
                            </div>
                            <div class="form-group">
                                <div class="col-12">
                                    <label class="labels" for="email_number2">Your <span class="mobile_number">mobile Number</span><span class="email">email</span> </label>
                                    <input type="text" class="formInput" id="email_number2" name="email_number2" />
                                    <span class="font12" id="demo"></span>
                                </div>
                            </div>
                            <div class="form-group mt-5">
                                <div class="col-12">
                                    <label class="labels" for="name">Name</label>
                                    <input type="text" class="formInput" id="name" name="name" />
                                    <span class="font12" id="demo"></span>
                                </div>
                            </div>
                            <div class="form-group my-5">
                                <div class="col-12">
                                    <label class="labels" for="mobile_number">Mobile Number</label>
                                    <input type="text" class="formInput" id="mobile_number" name="mobile_number"/>
                                    <span class="font12" id="demo"></span>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-12">
                                    <label class="labels" for="password">Password</label>
                                    <input type="text" class="formInput" id="password" name="password" />
                                    <span class="font12" id="demo"></span>
                                    <span class="font12" id="demo1"></span>
                                </div>
                            </div>
                            <div class="form-group px-2">
                                <input type="submit" class="modal-frm-btn" value="continue" />
                            </div>
                        </div>

                    </form>	
                </div>  
            </div>
        </div>
        
      </div>
    </div>
</div>	

</div>

<script src="js/jquery.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/particles.min.js"></script>
<script src="js/particles-script.js"></script>
<script src="js/particles.min.js"></script>
<script src="js/dot-animation.js"></script>
<script src="js/select1.min.js"></script>
<script src="js/select2.min.js"></script>
<script src="js/scrollTop.js"></script>
<script>
$('.select1').select1();
</script>
<script>
$('.select2').select2();
</script>
<script src="https://kit.fontawesome.com/526226c8c8.js" crossorigin="anonymous"></script>

<script src="js/materialForm.js"></script>


<script type="text/javascript">
    function myFunction(){

        var email_number = document.myForm1.email_number.value;
            
            if((/^(\+91|\+91\-|0)?[6789]\d{8}$/).test(email_number))
            {
                document.getElementById("demo").style.display = "none";
            }
            else if((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(email_number))
            {
                document.getElementById("demo").style.display = "none";
            }
            else
            {
                document.getElementById("demo").innerHTML = "Please provide vaild number or email !";
                return false;
            }
            
    }
</script>

<script>
    function validateForm() {
        var email_number = document.myForm1.email_number.value;
            
            if((/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/).test(email_number))
            {
                $(document).ready(function(){
                    $('.firstTab').hide();
                    $('.secondTab').show();
                });
            }
            else if((/^(\+91|\+91\-|0)?[6789]\d{9}$/).test(email_number))
            {
                $(document).ready(function(){
                    $('.firstTab').hide();
                    $('.secondTab').show();
                });
            }
            else
            {
                document.getElementById("demo").innerHTML = "Please provide vaild number or email !";
            }
    }
</script>

<script>
    $(window).ready(function(){
        $('.back-to-home').click(function(){
            $('.secondTab').hide();
            $('.firstTab').show();
        });
    });
</script>

<script type="text/javascript">

    $(window).ready(function(){
        $('.for-sale-btn').click(function(){
            $('.Search-area').show();
            $('.Search-area1').hide();
            $('.for-sale-btn').css({"background":"#fff", "color":"#000"});
            $('.To-Rent-btn').css({"boder":"1.5px solid #fff", "color":"#fff", "background":"transparent"});

        });
    });
    $(window).ready(function(){
        $('.To-Rent-btn').click(function(){
            $('.Search-area1').show();
            $('.Search-area').hide();
            $('.To-Rent-btn').css({"background":"#fff", "color":"#000"});
            $('.for-sale-btn').css({"boder":"1.5px solid #fff", "color":"#fff", "background":"transparent"});

        });
    });

</script>


</body>
</html>