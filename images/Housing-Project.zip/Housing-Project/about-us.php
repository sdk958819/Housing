    <?php

        include("header.php");

    ?>
   

    <br/><br/><br/>
    
    <section class="about-us-section">
    </section>

    <section class="about-section-content my-5">
        <div class="container">
            <h1 class="text-center">For Long Term or Short Term, We are with You</h1>
            <p class="text-center">
                Enticing Apartments, a growing name in the industry of selling Hotel Apartments, Villas and Penthouses having immense experience of dealing with all sort of budget and client's requirements.
            </p>
            <div class="row mt-5">
                <div class="col-lg-6 my-3">
                    <img src="images/04.png" alt="" class="abt-img"/>
                </div>
                <div class="col-lg-6 my-3">
                    <h3>LeEnticing Global Tourism LLC</h3>
                    <p class="text-justify">
                        Enticing Apartments is a product of LeEnticing Global Tourism LLC, Dubai offers its clients with the most luxurious and affordable range of Hotel Apartments, Villas, and Penthouses. The accommodation facilities we serve are very much competitive for the existing market standards.
                    </p>
                    <p class="text-justify">
                        We always look after our clients so that they will get the best from us in comparison to the market within their budget. We sell our services for both short-term, from 1 to 14 days to long term, which is more than 14 days. We have experts in our team who works dedicatedly and know how to fullfil our client's requirement in the best possible way. We comprise of the vast range of Hotel Apartments, Villas and Penthouses all in different price range, so it will be helpful for our clients to choose their residential dream place as per their budget.
                    </p>
                </div>
            </div>

            <div class="my-4">
                <h1 class="text-effect text-center">Our Services</h1>
                <p class="text-center">
                    Enticing Apartments, a growing name in the industry of selling Hotel Apartments, Villas and Penthouses having immense experience of dealing with all sort of budget and client's requirements.
                </p>
                <div class="row">
                    <div class="col-lg-4 my-3">
                        <div class="services-content p-3">
                            <img src="images/marketing.png" alt="" class="services-img" />
                            <h3 class="text-center">Marketing</h3>
                            <p class="text-justify">
                                Marketing refers to activities a company undertakes to promote the buying or selling of a product or service.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 my-3">
                        <div class="services-content p-3">
                            <img src="images/cunsulting.png" alt="" class="services-img" />
                            <h3 class="text-center">Consulting</h3>
                            <p class="text-justify">
                                Consulting is defined as the practise of providing a third party with expertise on a matter in exchange for a fee.
                            </p>
                        </div>
                    </div>
                    <div class="col-lg-4 my-3">
                        <div class="services-content p-3">
                            <img src="images/strategy.png" alt="" class="services-img" />
                            <h3 class="text-center">Strategy</h3>
                            <p class="text-justify">
                                Strategy generally involves setting goals, determining actions to achieve the goals, and mobilizing resources to execute the actions.
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="my-4">
                <h1 class="text-effect text-center">Clients</h1>
                 <p class="text-center">
                    Enticing Apartments, a growing name in the industry of selling Hotel Apartments, Villas and Penthouses having immense experience of dealing with all sort of budget and client's requirements.
                </p>
                <div class="row">
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/google.png" alt="" class="client-icons" />
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/apple.png" alt="" class="client-icons" />
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/microsoft.png" alt="" class="client-icons" />
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/intel.png" alt="" class="client-icons" />
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/hyundai.png" alt="" class="client-icons" />
                        </div>
                    </div>
                    <div class="col-lg-2 col-6 my-3">
                        <div class="p-2 text-center">
                            <img src="images/amozon.png" alt="" class="client-icons" />
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>


    <?php

        include("footer.php");

    ?>
    

