		
	<?php

		include("header.php");

	?>
	
		<section class="section-one">
			<div class="container">
				<div class="row">
					<div class="col-lg-4 larg-size-block">
						<div class="side-content p-2">
							<h5 class="text-center">Properties in Delhi</h5>
							<div class="d-flex">
								<img src="images/house1.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy - Apartments / Flats</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 60 Lakhs</a> / 
										<a href="#">60 lakhs - 80 lakhs</a> / 
										<a href="#">80lakhs - 1 crore</a>
									</p>
								</div>
							</div>
							<div class="d-flex">
								<img src="images/builing.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Rent - Apartments / Flats</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 20k</a> / 
										<a href="#">20k - 30k</a> / 
										<a href="#">30k - 40k</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/house2.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy - Houses / Villas</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 80 Lakhs</a> / 
										<a href="#">80lakhs - 1 crore</a> / 
										<a href="#">1 crore +</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/plot.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy land / plots</h6></a>
									<p class="font12 flat-link">
										<a href="#">Commercial</a> / 
										<a href="#"> Agriculture</a> / 
										<a href="#"> Residential</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/building.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Projects</h6></a>
									<p class="font12 flat-link">
										<a href="#">Ready to Move</a> / 
										<a href="#"> Ongoing</a> / 
										<a href="#"> RERA Regd</a>
									</p>
								</div>
							</div>

						</div>
					</div>

					<div class="col-lg-8">
						<h3 class="text-center text-white">Buy, Rent your dream property.</h3>
						<div class="my-4 mt-5">
							<div class="text-center">
								<a href="#" class="To-Rent-btn mr-2">TO RENT</a>
								<a href="#" class="for-sale-btn ml-2">FOR SALE</a>
							</div>   
							<div class="Search-area1">
								<div class="signal-arrow-up1"></div>
		
								<form class="p-4">
									<label class="font12">LOCATION</label>
									<div class="row">
										<div class="col-lg-3 col-md-4 col-sm-12 col-12 p-1">
											<div class="d-flex">
												<select class="form-control select2">
													<option value="0">Delhi</option>
													<option value="1">Bangalore</option>
													<option value="2">Chnadigarh</option>
													<option value="3">Chennai</option>
													<option value="4">Hyderabad</option>
													<option value="5">Kolkata</option>
													<option value="6">Mumbai</option>
													<option value="7">Pune</option>
												</select>
											</div>
										</div>
										<div class="col-lg-7 col-md-4 col-sm-6 col-6 p-0 mt-1">
											<input type="text" placeholder="search project, locality, landmark..." class="searchbox font14" />
										</div>
										<div class="col-lg-2 col-md-4 col-sm-6 col-6 p-1">
											<button class="btn send-btn">SEND</button>
										</div>
									</div>
		
									<div class="row my-2">
		
										<div class="col-lg-3 col-md-6 col-6 p-0 px-1">
											<label class="font12">PROPERTY TYPE</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="">Select Category Name</option>
													<option value="1">Apartment</option>
													<option value="2">Vila</option>
													<option value="3">Townhouse</option>
													<option value="4">Penthouse</option>
													<option value="5">Vila-Compound</option>
													<option value="6">Residential-Plot</option>
													<option value="7">Residential-Floor</option>
												</select>
											</div>
										</div>
		
										<div class="col-lg-3 col-md-6 col-6 p-0 px-1">
											<label class="font12">RENT FREQUENCY</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="selected">Yearly</option>
													<option value="1">Monthly</option>
													<option value="2">Weekly</option>
													<option value="3">Daily</option>
													<option value="4">Any</option>
												</select>
											</div>
										</div>
		
										<div class="col-lg-3 col-md-6 col-6 p-0 px-1">
											<label class="font12">PRICE</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="selected">All</option>
													<option value="1">20,000</option>
													<option value="2">30,000</option>
													<option value="3">40,000</option>
													<option value="4">50,000</option>
													<option value="5">60,000</option>
													<option value="6">70,000</option>
													<option value="7">80,000r</option>
												</select>
											</div>
										</div>
		
										<div class="col-lg-3 col-md-6 col-6 p-0 px-1">
											<label class="font12">BEDS</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="selected">All</option>
													<option value="0">Studio</option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
													<option value="4">4</option>
													<option value="5">5</option>
													<option value="6">6</option>
													<option value="7">7</option>
													<option value="8">8</option>
													<option value="8+">8+</option>
												</select>
											</div>
										</div>
		
									</div>
								</form>
							</div>
		
							<div class="Search-area">
								<div class="signal-arrow-up"></div>
								<form class="p-4">
									<label class="font12">LOCATION</label>
									<div class="row">
										<div class="col-lg-3 col-md-4 col-sm-12 col-12 p-1">
											<div class="d-flex">
												<select class="form-control select2">
													<option value="0">Delhi</option>
													<option value="1">Bangalore</option>
													<option value="2">Chnadigarh</option>
													<option value="3">Chennai</option>
													<option value="4">Hyderabad</option>
													<option value="5">Kolkata</option>
													<option value="6">Mumbai</option>
													<option value="7">Pune</option>
												</select>
											</div>
										</div>
										<div class="col-lg-7 col-md-4 col-sm-6 col-6 p-0 mt-1">
											<input type="text" placeholder="search project, locality, landmark..." class="searchbox font14" />
										</div>
										<div class="col-lg-2 col-md-4 col-sm-6 col-6 p-1">
											<button class="btn send-btn">SEND</button>
										</div>
									</div>
		
									<div class="row my-2">
		
										<div class="col-lg-4 col-md-6 col-6 p-0 px-1">
											<label class="font12">PROPERTY TYPE</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="">Select Category Name</option>
													<option value="1">Apartment</option>
													<option value="2">Vila</option>
													<option value="3">Townhouse</option>
													<option value="4">Penthouse</option>
													<option value="5">Vila-Compound</option>
													<option value="6">Residential-Plot</option>
													<option value="7">Residential-Floor</option>
												</select>
											</div>
										</div>
		
										<div class="col-lg-4 col-md-6 col-6 p-0 px-1">
											<label class="font12">PRICE</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="selected">All</option>
													<option value="1">20,000</option>
													<option value="2">30,000</option>
													<option value="3">40,000</option>
													<option value="4">50,000</option>
													<option value="5">60,000</option>
													<option value="6">70,000</option>
													<option value="7">80,000r</option>
												</select>
											</div>
										</div>
		
										<div class="col-lg-4 col-md-6 col-6 p-0 px-1">
											<label class="font12">BEDS</label>
											<div class="d-flex">
												<select class="form-control select2">
													<option value="selected">All</option>
													<option value="0">Studio</option>
													<option value="1">1</option>
													<option value="2">2</option>
													<option value="3">3</option>
													<option value="4">4</option>
													<option value="5">5</option>
													<option value="6">6</option>
													<option value="7">7</option>
													<option value="8">8</option>
													<option value="8+">8+</option>
												</select>
											</div>
										</div>
		
									</div>
								</form>
								
							</div>
						</div>
					</div>

					<div class="col-lg-4 small-size-block">
						<div class="side-content p-2">
							<h5 class="text-center">Properties in Delhi</h5>
							<div class="d-flex">
								<img src="images/house1.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy - Apartments / Flats</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 60 Lakhs</a> / 
										<a href="#">60 lakhs - 80 lakhs</a> / 
										<a href="#">80lakhs - 1 crore</a>
									</p>
								</div>
							</div>
							<div class="d-flex">
								<img src="images/builing.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Rent - Apartments / Flats</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 20k</a> / 
										<a href="#">20k - 30k</a> / 
										<a href="#">30k - 40k</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/house2.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy - Houses / Villas</h6></a>
									<p class="font12 flat-link">
										<a href="#">Below 80 Lakhs</a> / 
										<a href="#">80lakhs - 1 crore</a> / 
										<a href="#">1 crore +</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/plot.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Buy land / plots</h6></a>
									<p class="font12 flat-link">
										<a href="#">Commercial</a> / 
										<a href="#"> Agriculture</a> / 
										<a href="#"> Residential</a>
									</p>
								</div>
							</div>

							<div class="d-flex">
								<img src="images/building.png" alt="" class="side-content-icon mr-3"/>
								<div>
									<a href="#"><h6>Projects</h6></a>
									<p class="font12 flat-link">
										<a href="#">Ready to Move</a> / 
										<a href="#"> Ongoing</a> / 
										<a href="#"> RERA Regd</a>
									</p>
								</div>
							</div>

						</div>
					</div>
				</div>

			</div>
		</section>

		<section class="section-second my-4">
			<div class="container">
				<h2>Featured Projects</h2>
				<p>Exclusive showcase of top projects</p>
				<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<a href="#">
							<div class="futured-projects">
								<img src="images/img1.jpg" alt="" class="featured-img" />
								<div class="p-2">
									<h4>Bricks Skywoods</h4>
									<p>By Bricks Infratech</p>

									<h5>3 BHK Apartment</h5>
									<p>Nallagandla, Hyderabad</p>

									<h5 class="font-weight-bold text-success"> &#x20B9; 96.62 L - 1.22 Cr</h5>

								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<a href="#">
							<div class="futured-projects">
								<img src="images/img2.jpg" alt="" class="featured-img" />
								<div class="p-2">
									<h4>Bricks Skywoods</h4>
									<p>By Bricks Infratech</p>

									<h5>3 BHK Apartment</h5>
									<p>Nallagandla, Hyderabad</p>

									<h5 class="font-weight-bold text-success"> &#x20B9; 89.45 L - 1.25 Cr</h5>

								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<a href="#">
							<div class="futured-projects">
								<img src="images/img3.jpg" alt="" class="featured-img" />
								<div class="p-2">
									<h4>Bricks Skywoods</h4>
									<p>By Bricks Infratech</p>

									<h5>3 BHK Apartment</h5>
									<p>Nallagandla, Hyderabad</p>

									<h5 class="font-weight-bold text-success"> &#x20B9; 84.62 L - 1.8 Cr</h5>

								</div>
							</div>
						</a>
					</div>
				</div>
			</div>
		</section>

		<section class="section-third my-5">
			<div class="container">
				<h2>Trending Projects</h2>
				<p>Most sought-after projects in Hyderabad</p>
				<div class="row">
					<div class="col-lg-4 col-md-6  my-4 effect">
						<a href="#">
							<div class="Trending-Projects d-flex effect">
								<div class="col-5 p-0">
									<img src="images/sm-img1.jpg" alt="" class="Trending-Projects-img" />
								</div>
								<div class="col-sm-7">
									<h4>Maruthi Elite</h4>
									<p class="font14">By Maruthi Developers</p>

									<h6>1,2,3,4 BHK Apartments</h6>
									<p class="font14">Rohini Sector 16, New Delhi</p>

									<h6>27 lakhs - 2.7 crore</h6>
								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-6  my-4 effect">
						<a href="#">
							<div class="Trending-Projects d-flex effect">
								<div class="col-5 p-0">
									<img src="images/sm-img2.jpg" alt="" class="Trending-Projects-img" />
								</div>
								<div class="col-sm-7">
									<h4>Maruthi Elite</h4>
									<p class="font14">By Maruthi Developers</p>

									<h6>1,2,3,4 BHK Apartments</h6>
									<p class="font14">Rohini Sector 16, New Delhi</p>

									<h6>27 lakhs - 2.7 crore</h6>
								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-6  my-4 effect">
						<a href="#">
							<div class="Trending-Projects d-flex effect">
								<div class="col-5 p-0">
									<img src="images/sm-img3.jpg" alt="" class="Trending-Projects-img" />
								</div>
								<div class="col-sm-7">
									<h4>Maruthi Elite</h4>
									<p class="font14">By Maruthi Developers</p>

									<h6>1,2,3,4 BHK Apartments</h6>
									<p class="font14">Rohini Sector 16, New Delhi</p>

									<h6>27 lakhs - 2.7 crore</h6>
								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-6  my-4 effect">
						<a href="#">
							<div class="Trending-Projects d-flex effect">
								<div class="col-5 p-0">
									<img src="images/sm-img4.jpg" alt="" class="Trending-Projects-img" />
								</div>
								<div class="col-sm-7">
									<h4>Maruthi Elite</h4>
									<p class="font14">By Maruthi Developers</p>

									<h6>1,2,3,4 BHK Apartments</h6>
									<p class="font14">Rohini Sector 16, New Delhi</p>

									<h6>27 lakhs - 2.7 crore</h6>
								</div>
							</div>
						</a>
					</div>

					<div class="col-lg-4 col-md-6  my-4 effect">
						<a href="#">
							<div class="Trending-Projects d-flex effect">
								<div class="col-5 p-0">
									<img src="images/sm-img5.jpg" alt="" class="Trending-Projects-img" />
								</div>
								<div class="col-sm-7">
									<h4>Maruthi Elite</h4>
									<p class="font14">By Maruthi Developers</p>

									<h6>1,2,3,4 BHK Apartments</h6>
									<p class="font14">Rohini Sector 16, New Delhi</p>

									<h6>27 lakhs - 2.7 crore</h6>
								</div>
							</div>
						</a>
					</div>
				</div>
			</div>
		</section>

		<section class="section-forth my-5">
			<div id="particles-js" style="position: absolute; width: 100%;">
			</div>
			<div class="container py-5">
				<h2 class="text-white">Enticing Apartment Research Facts</h2>
				<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="bg-white p-3">
							<img src="images/log.png" alt="" class="Research-Facts"/>
							<h5>Real Estate Consumer Sentiments</h5>
							<p>Report 2018</p>

							<p class="font12">Indian Consumer's Home-buying Sentiment this Festive Season 2018 Edition</p>
							<a href="#" class="btn btn-block btn-primary"> Raad More</a>
						</div>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="bg-white p-3">
							<img src="images/log.png" alt="" class="Research-Facts"/>
							<h5>Real Estate Consumer Sentiments</h5>
							<p>Report 2018</p>

							<p class="font12">Indian Consumer's Home-buying Sentiment this Festive Season 2018 Edition</p>
							<a href="#" class="btn btn-block btn-primary"> Raad More</a>
						</div>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="bg-white p-3">
							<img src="images/log.png" alt="" class="Research-Facts"/>
							<h5>Real Estate Consumer Sentiments</h5>
							<p>Report 2018</p>

							<p class="font12">Indian Consumer's Home-buying Sentiment this Festive Season 2018 Edition</p>
							<a href="#" class="btn btn-block btn-primary"> Raad More</a>
						</div>
					</div>
				</div>
			</div>
		</section>

		<section class="section-fifth my-5 py-5">
			<div class="container">
				<h2 class="text-center">Making Real Estate Easy!</h2>
				<div class="row">
					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="text-center Making-Real p-4">
							<img src="images/builder.png" alt="" class="Making-Real-img mb-2" />
							<h3>15,000+</h3>
							<p>Builders</p>
						</div>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="text-center Making-Real p-4">
							<img src="images/house.png" alt="" class="Making-Real-img mb-2" />
							<h3>15,95,000+</h3>
							<p>Properties</p>
						</div>
					</div>

					<div class="col-lg-4 col-md-4 col-sm-6 my-4">
						<div class="text-center Making-Real p-4">
							<img src="images/city.png" alt="" class="Making-Real-img mb-2" />
							<h3>1,20,000+</h3>
							<p>Projects</p>
						</div>
					</div>
				</div>
			</div>
		</section>

	<?php

		include("footer.php");

	?>