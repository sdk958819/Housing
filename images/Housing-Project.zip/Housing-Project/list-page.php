    <?php

        include("header.php");

    ?>
   

    <br/><br/><br/>
    
    <section class="first-section">
        <div class="container">
            <div class="row">

                <div class="col-lg-3 my-3 bg-white" id="StickyTop">
                    <div class="filter text-center bgclr p-3 rounded">
                        <h4 class="font-weight-bold"><i class="fas fa-sort-amount-down"></i> Sort & Filter</h4>
                    </div>
                    <div class="border rounded my-3">
                        <form>
                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#cities">
                                <span class="clr font16 font-weight-bold">Cities</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="cities" class="collapse px-3">
                                <hr/>
                                <label for="dl" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="dl" />
                                        <span>Delhi</span>
                                </label>
                                <label for="gd" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="gd" />
                                        <span>Ghaziabad</span>
                                </label>
                                <label for="fb" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="fb" />
                                        <span>Faridabad</span>
                                </label>
                                <label for="gg" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="gg" />
                                        <span>Gurugram</span>
                                </label>
                                <label for="nd" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="nd" />
                                        <span>Noida</span>
                                </label>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3" type="button" data-toggle="collapse" data-target="#locality">
                                <span class="clr font16 font-weight-bold">Localities</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="locality" class="collapse px-3 pt-2">
                                <hr/>
                                <div class="d-flex">
                                    <select class="form-control select2">
                                        <option value="0">Delhi</option>
                                        <option value="1">Bangalore</option>
                                        <option value="2">Chnadigarh</option>
                                        <option value="3">Chennai</option>
                                        <option value="4">Hyderabad</option>
                                        <option value="5">Kolkata</option>
                                        <option value="6">Mumbai</option>
                                        <option value="7">Pune</option>				
                                    </select>
                                </div>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3" type="button" data-toggle="collapse" data-target="#landmark">
                                <span class="clr font16 font-weight-bold">Near By Landmark</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="landmark" class="collapse px-3 pt-2">
                                <hr/>
                                <div class="d-flex">
                                    <select class="form-control select2">
                                        <option value="0">Delhi</option>
                                        <option value="1">Bangalore</option>
                                        <option value="2">Chnadigarh</option>
                                        <option value="3">Chennai</option>
                                        <option value="4">Hyderabad</option>
                                        <option value="5">Kolkata</option>
                                        <option value="6">Mumbai</option>
                                        <option value="7">Pune</option>				
                                    </select>
                                </div>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3">
                                <span class="clr font16 font-weight-bold">Price</span>
                            </a>
                            <div class="d-flex px-3 pt-2">
                                <input id="slider11" class="border-0" type="range" min="0" max="200000" />
                                <span class="font-weight-bold text-primary ml-2 mt-1 valueSpan"></span>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3" type="button" data-toggle="collapse" data-target="#budget">
                                <span class="clr font16 font-weight-bold">Budget</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="budget" class="collapse px-3 pt-2">
                                <hr/>
                                <div class="d-flex justify-content-between">
                                    <div class="col-lg-6">
                                        <select class="form-control select2">
                                            <option value="0">Min</option>
                                            <option value="1">10 K</option>
                                            <option value="2">20 k</option>
                                            <option value="3">30 k</option>
                                            <option value="4">40 k</option>
                                            <option value="5">50 k</option>
                                            <option value="6">60 k</option>
                                            <option value="7">70 k</option>				
                                            <option value="8">80 k</option>				
                                            <option value="9">90 k</option>				
                                            <option value="10">1 Lakh</option>				
                                        </select>
                                    </div>

                                    <div class="col-lg-6">
                                        <select class="form-control select2">
                                            <option value="0">Max</option>
                                            <option value="1">10 Lakh</option>
                                            <option value="2">20 Lakh</option>
                                            <option value="3">30 Lakh</option>
                                            <option value="4">40 Lakh</option>
                                            <option value="5">50 Lakh</option>
                                            <option value="6">60 Lakh</option>
                                            <option value="7">70 Lakh</option>				
                                            <option value="8">80 Lakh</option>				
                                            <option value="9">90 Lakh</option>				
                                            <option value="10">1 Crore</option>				
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#property">
                                <span class="clr font16 font-weight-bold">Property Type</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="property" class="collapse px-3">
                                <hr/>
                                <label for="ap" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="ap" />
                                        <span>Apartments</span>
                                </label>
                                <label for="vl" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="vl" />
                                        <span>Villa</span>
                                </label>
                                <label for="fb" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="fb" />
                                        <span>Builder Floors</span>
                                </label>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#beds">
                                <span class="clr font16 font-weight-bold">Beds</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="beds" class="collapse px-3">
                                <hr/>
                                <label for="1bhk" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="1bhk" />
                                        <span>1 BHK</span>
                                </label>
                                <label for="2bhk" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="2bhk" />
                                        <span>2 BHK</span>
                                </label>
                                <label for="3bhk" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="3bhk" />
                                        <span>3 BHK</span>
                                </label>
                                <label for="3bhk+" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="3bhk+" />
                                        <span>3 BHK+</span>
                                </label>
                            </div>
                            <hr>
                            
                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#available">
                                <span class="clr font16 font-weight-bold">Available From</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="available" class="collapse px-3">
                                <hr/>
                                <label for="Immediately" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="Immediately" />
                                        <span>Immediately</span>
                                </label>
                                <label for="CurrentMonth" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="CurrentMonth" />
                                        <span>Current Month</span>
                                </label>
                                <label for="july2020" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="july2020" />
                                        <span>july 2020</span>
                                </label>
                                <label for="aug2020" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="aug2020" />
                                        <span>Aug 2020</span>
                                </label>
                                <label for="after3Months" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="after3Months" />
                                        <span>After Three Months</span>
                                </label>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#amenities">
                                <span class="clr font16 font-weight-bold">Amenities</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="amenities" class="collapse px-3">
                                <hr/>
                                <label for="lift" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="lift" />
                                        <span>Lift</span>
                                </label>
                                <label for="gym" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="gym" />
                                        <span>Gym</span>
                                </label>
                                <label for="playArea" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="playArea" />
                                        <span>Play Area</span>
                                </label>
                                <label for="cameras" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="cameras" />
                                        <span>CCTV Cameras</span>
                                </label>
                                <label for="BankATM" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="BankATM" />
                                        <span>Bank / ATML</span>
                                </label>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3 pt-2" type="button" data-toggle="collapse" data-target="#Furnishing">
                                <span class="clr font16 font-weight-bold">Furnishing Status</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="Furnishing" class="collapse px-3">
                                <hr/>
                                <label for="fullyFurnished" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="fullyFurnished" />
                                        <span>Fully Furnished</span>
                                </label>
                                <label for="SemiFurnished" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="SemiFurnished" />
                                        <span>Semi Furnished</span>
                                </label>
                                <label for="Unfurnished" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="Unfurnished" />
                                        <span>Unfurnished</span>
                                </label>
                            </div>
                            <hr>

                            <a href="#" class="d-flex justify-content-between px-3 pt-2 pb-3" type="button" data-toggle="collapse" data-target="#IndoorAmenities">
                                <span class="clr font16 font-weight-bold">Indoor Amenities</span>
                                <i class="fas fa-angle-down text-muted font22"></i>
                            </a>
                            <div id="IndoorAmenities" class="collapse px-3">
                                <hr/>
                                <label for="AirCondition" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="AirCondition" />
                                        <span>Air Condition</span>
                                </label>
                                <label for="TV" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="TV" />
                                        <span>TV</span>
                                </label>
                                <label for="Geyzer" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="Geyzer" />
                                        <span>Geyzer</span>
                                </label>
                                <label for="WesternToilet" class="list-label clr font16">
                                    <input type="checkbox" name="checkbox" class="mr-2" id="WesternToilet" />
                                        <span>Western Toilet</span>
                                </label>
                            </div>
                        </form>

                    </div>
                </div>

                <div class="col-lg-9 my-4">

                    <div class="row list-package abcd py-2 mb-4">
                        <div class="col-lg-4 col-md-3 col-sm-12 listpage">
                            <img src="images/sm-img1.jpg" alt="" />
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-12">
                            <h5 class="font-weight-bold">3 BHK 1100 Sq. ft Apartment for rent in Munirka, Delhi</h5>
                            <div class="d-flex my-2 font12">
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <span class="font12 text-warning ml-2">4</span>
                                <span class="font12 lightclr ml-2">365 reviews</span>
                            </div>
                            <div class="font12">
                               
                                <p class="para">
                                    DDA Flats Munirka, Munirka, Delhi
                                </p>
                                <p class="para">
                                    <span>BUILT-UP AREA : </span>
                                    <strong>1100 Sq.Ft. </strong>
                                </p>
                                <p class="para">
                                    <span>POSTED : </span>
                                    <strong>17-may-2020</strong>
                                </p>
                                <p class="para">
                                    <span>DEPOSIT PRICE : </span>
                                    <strong>
                                        68000
                                    </strong>
                                </p>
                                <p class="para">
                                    <span>Amenities: </span>
                                    <strong>
                                        <a href="#">Gated Community</a>, 
                                        <a href="#">Car Parking</a>, 
                                        <a href="#">Jogging Track</a>, 
                                        <a href="#">Landscaped Garden</a>, 
                                    </strong>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-12">
                            <p class="font14">
                                Beautifully renovated 2nd floor property in a safe and well gated soci...
                                <a href="#">Read More</a>
                            </p>

                            <h6>Deepak Singh</h6>
                            <p>Individual</p>

                            <h5 class="txtclr font-weight-bold">&#x20B9; 79,000</h5>
                            <a href="#" class="btn btn-outline-success btn-block">Contact</a>
                            <a href="https://goo.gl/maps/9v68YautTP6ZGAAWA" target="_blank" class="btn btn-primary btn-block">Track Location</a>
                        </div>
                    </div>

                    <div class="row list-package py-2 mb-4">
                        <div class="col-lg-4 col-md-3 col-sm-12 listpage">
                            <img src="images/sm-img2.jpg" alt="" />
                        </div>
                        <div class="col-lg-5 col-md-5 col-sm-12">
                            <h5 class="font-weight-bold">3 BHK 1100 Sq. ft Apartment for rent in Munirka, Delhi</h5>
                            <div class="d-flex my-2 font12">
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <i class="fas fa-star text-warning"></i>
                                <span class="font12 text-warning ml-2">4</span>
                                <span class="font12 lightclr ml-2">365 reviews</span>
                            </div>
                            <div class="font12">
                               
                                <p class="para">
                                    DDA Flats Munirka, Munirka, Delhi
                                </p>
                                <p class="para">
                                    <span>BUILT-UP AREA : </span>
                                    <strong>1100 Sq.Ft. </strong>
                                </p>
                                <p class="para">
                                    <span>POSTED : </span>
                                    <strong>17-may-2020</strong>
                                </p>
                                <p class="para">
                                    <span>DEPOSIT PRICE : </span>
                                    <strong>
                                        68000
                                    </strong>
                                </p>
                                <p class="para">
                                    <span>Amenities: </span>
                                    <strong>
                                        <a href="#">Gated Community</a>, 
                                        <a href="#">Car Parking</a>, 
                                        <a href="#">Jogging Track</a>, 
                                        <a href="#">Landscaped Garden</a>, 
                                    </strong>
                                </p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-4 col-sm-12">
                            <p class="font14">
                                Beautifully renovated 2nd floor property in a safe and well gated soci...
                                <a href="#">Read More</a>
                            </p>

                            <h6>Deepak Singh</h6>
                            <p>Individual</p>

                            <h5 class="txtclr font-weight-bold">&#x20B9; 79,000</h5>
                            <a href="#" class="btn btn-outline-success btn-block">Contact</a>
                            <a href="https://goo.gl/maps/9v68YautTP6ZGAAWA" target="_blank" class="btn btn-primary btn-block">Track Location</a>
                        </div>
                    </div>

                </div>

            </div>
            
        </div>
    </section>


    <?php

        include("footer.php");

    ?>
    <script>
        $(document).ready(function() {

          const $valueSpan = $('.valueSpan');
          const $value = $('#slider11');
          $valueSpan.html($value.val());
          $value.on('input change', () => {

            $valueSpan.html($value.val());
          });
        });
    </script>

