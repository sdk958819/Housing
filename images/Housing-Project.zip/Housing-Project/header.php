<!DOCTYPE html>
<html>
<head>
	<title>Housing Project</title>
	<meta charset="utf-8">
  	<meta name="viewport" content="width=device-width, initial-scale=1"/>
  	<link rel="stylesheet" href="css/bootstrap.min.css"/>
  	<link rel="stylesheet" href="css/style.css"/>
  	<link rel="stylesheet" href="css/select1.min.css"/>
  	<link rel="stylesheet" href="css/select2.min.css"/>
  	<link rel="stylesheet" href="css/materialFormStyles.css"/>
  	<link rel="stylesheet" href="css/scrollTop.css"/>
</head>
<style>
	.modal
	{
		background: rgba(255,255,255, 0.7) !important;
	}
	.modal-content
	{
		border-radius: 0px !important;
		box-shadow: 0 4px 18px 0 rgba(0, 0, 0, 0.3);
		border: none !important;
	}
	.close
	{
		position: relative;
	}
	.select2
	{
		width: 100% !important;
	}
</style>
<body>
	<div class="main-hero">
		<!-- <canvas id="canvas-1"></canvas> -->

        <header class="header-area fixed-top" id="header">
	    	<div class="container">
	    		<nav class="navbar navbar-expand-lg">
	                <a href="#" class="navbar-brand">
						<img src="images/logo.png" class="logo">
						<img src="images/logo1.png" class="logo1">
					</a>
					<div class="ml-3">
						<form action="/Category/WallpaperByCategoryName">
							<input id="id" name="id" type="hidden" value="mainhome" />
							<div class="d-flex">
								<p><i class="fas fa-map-marker-alt font12 mt-3"></i></p>
								<select class="select1" id="categorytypename" name="categorytypename">
									<option value="0">Delhi</option>
									<option value="1">Bangalore</option>
									<option value="2">Chnadigarh</option>
									<option value="3">Chennai</option>
									<option value="4">Hyderabad</option>
									<option value="5">Kolkata</option>
									<option value="6">Mumbai</option>
									<option value="7">Pune</option>
								</select>
							</div>
						</form>
					</div>
                    
                    <!-- <form>
							<div class="row">
								<div class="col-lg-3 col-md-4 col-sm-12 col-12 p-1">
									<div class="d-flex">
										<select class="form-control select2">
											<option value="0">Delhi</option>
											<option value="1">Bangalore</option>
											<option value="2">Chnadigarh</option>
											<option value="3">Chennai</option>
											<option value="4">Hyderabad</option>
											<option value="5">Kolkata</option>
											<option value="6">Mumbai</option>
											<option value="7">Pune</option>
										</select>
									</div>
								</div>
							    <div class="col-lg-7 col-md-4 col-sm-6 col-6 p-0 mt-1">
									<input type="text" placeholder="search..." class="searchbox font14" />
								</div>
								<div class="col-lg-2 col-md-4 col-sm-6 col-6 p-1">
									<button class="btn send-btn">SEND</button>
								</div>
						    </div>
									
					</form>            -->
                    
					<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
						<span><i class="fas fa-bars"></i></span>
					 </button>
					<div class="collapse navbar-collapse mt-2 mb-2" id="collapsibleNavbar">
						<ul class="navbar-nav ml-auto">
							<li class="nav-item" data-toggle="modal" data-target="#myModal">
								<a href="#" class="nav-link">
									<i class="far fa-user mr-2"></i>
									Login / Register
								</a>
							</li>
							<li class="nav-item">
								<a href="#" class="nav-link1">
									Sell / Rent Property Free
								</a>
							</li>
						</ul>
					</div>
	            </nav>
			</div>
		</header>